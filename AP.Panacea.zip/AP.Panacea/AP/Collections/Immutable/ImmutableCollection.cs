﻿#if fx45
namespace AP.Collections.Immutable
{
    public class ImmutableCollection<T>
    {}
}
#endif