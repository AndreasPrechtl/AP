﻿namespace AP.Routing
{
    public enum UriSegmentType
    {
        Fixed,
        Template
    }
}