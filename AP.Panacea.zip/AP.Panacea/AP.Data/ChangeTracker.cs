﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AP.Data
{
    public class ChangeTracker
    {
        private readonly Dictionary<object, ChangeType>

        internal ChangeTracker()
        {
            
        }

    }
}
