﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AP.UI
{
    public interface IPage
    {
        PageMetaData MetaData { get; }
    }
}
