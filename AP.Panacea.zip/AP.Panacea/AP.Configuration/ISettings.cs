﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AP.Configuration
{
    /// <summary>
    /// Interface for settings.
    /// </summary>
    public interface ISettings //: AP.Collections.Specialized.NameValueDictionary<object>
    {
    }
}
