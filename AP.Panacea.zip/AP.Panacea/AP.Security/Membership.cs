﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AP.Security
{
    public static class Membership
    {
        public static MembershipContextBase Context { get; set; }
    }
}
