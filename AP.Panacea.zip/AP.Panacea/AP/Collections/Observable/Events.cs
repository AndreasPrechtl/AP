﻿namespace AP.Collections.Observable
{
    public static class Events
    {
        //public static void Raise(this NotifyCollectionChangedEventHandler handler, object sender, CollectionChangedEventArgs e)
        //{
        //    if (handler != null)
        //        handler(sender, e);
        //}
        //public static void Raise(this NotifyCollectionChangingEventHandler handler, object sender, CollectionChangingEventArgs e)
        //{
        //    if (handler != null)
        //        handler(sender, e);
        //}
        //public static void Raise<T>(this NotifyCollectionChangedEventHandler<T> handler, object sender, CollectionChangedEventArgs<T> e)
        //{
        //    if (handler != null)
        //        handler(sender, e);
        //}
        //public static void Raise<T>(this NotifyCollectionChangingEventHandler<T> handler, object sender, CollectionChangingEventArgs<T> e)
        //{
        //    if (handler != null)
        //        handler(sender, e);
        //}
    }
}
