﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AP.Security
{
    public enum PermissionType
    {
        Inherit = 0,
        Allow = 3,
        Deny = 7       
    }
}
