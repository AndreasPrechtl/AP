﻿using AP.ComponentModel;
using AP.UniformIdentifiers;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Text;

namespace AP.IO
{   
    /// <summary>
    /// Helper class for file manipualation, purely designed for extension methods.
    /// </summary>
    public class FilesHelper
    { }
}
