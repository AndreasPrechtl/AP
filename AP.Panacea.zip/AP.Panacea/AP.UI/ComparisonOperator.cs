﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AP.UI
{
    internal enum ComparisonOperator : sbyte
    {
        Less = -1,
        Equal = 0,
        Greater = 1
    }
}
