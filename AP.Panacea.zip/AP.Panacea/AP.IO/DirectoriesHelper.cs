﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.IO;
using System.Security.AccessControl;
using AP.ComponentModel;
using AP.UniformIdentifiers;

namespace AP.IO
{
    /// <summary>
    /// Helper class for directory manipulation, purely designed for extension methods.
    /// </summary>
    public class DirectoriesHelper
    { }
}
