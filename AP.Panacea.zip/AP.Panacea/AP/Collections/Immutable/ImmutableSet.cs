﻿#if fx45
namespace AP.Collections.Immutable
{
    public class ImmutableSet<TKey, TValue>
    {}
}
#endif