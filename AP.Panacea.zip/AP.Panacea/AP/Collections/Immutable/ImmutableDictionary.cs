﻿#if fx45
namespace AP.Collections.Immutable
{
    public class ImmutableDictionary<TKey, TValue>
    {}
}
#endif